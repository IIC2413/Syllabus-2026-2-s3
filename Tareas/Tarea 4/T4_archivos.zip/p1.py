"""
Parte 1: Incumplimiento de la Capacidad de Despacho del Vendedor

Ejecutar con:  python3 sesiones.py --db bdd_t4 --parte 1
"""

from sesiones import Sesion


def parte_1():
    pass
