"""
Parte 2: El caso del recargo logístico perdido #1

Ejecutar con:  python3 sesiones.py --db bdd_t4 --parte 2
"""

from sesiones import Sesion


def parte_2():
    pass
