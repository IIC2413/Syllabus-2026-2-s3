# IIC2413 - Tarea 4

Este archivo solamente contiene información para los problemas más comunes de instalación y conexión.

| Mensaje | Solución |
|---|---|
| `role "..." does not exist` | Cree un rol con su nombre de usuario (`sudo -u postgres createuser --superuser $USER`) o defina `PGUSER=postgres`. |
| `password authentication failed` / `fe_sendauth: no password supplied` | Defina las variables de entorno `PGUSER` y `PGPASSWORD`. Sirven tanto para `psql`/`createdb` como para `sesiones.py`. |
| `connection refused` / `could not connect to server` | El servidor PostgreSQL no está corriendo. |
| `data/olist_...csv: No such file or directory` | Ejecute `psql` desde la carpeta de la tarea y revise que `data/` tenga los ocho `.csv`. |
| `ModuleNotFoundError: No module named 'psycopg2'` | `pip install psycopg2-binary` (con el mismo Python con el que ejecuta `sesiones.py`). |

Las variables de entorno estándar de PostgreSQL (`PGHOST`, `PGPORT`, `PGUSER`,
`PGPASSWORD`) permiten conectarse a un servidor con otra configuración sin
modificar ningún archivo. En Windows el comando de Python suele ser `python`
en vez de `python3`.
