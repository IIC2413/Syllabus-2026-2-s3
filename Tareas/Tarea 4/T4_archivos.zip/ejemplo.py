"""
IIC2413 - Tarea 4 - Ejemplo de dos sesiones concurrentes (no modifica los datos).

Ejecutar con:  python3 sesiones.py --db bdd_t4 --ejemplo
"""

from sesiones import Sesion


def ejemplo():
    T1 = Sesion("T1")
    T2 = Sesion("T2")
    contar = "SELECT COUNT(*) AS categorias FROM category_translation"

    T1.run_query(contar)
    T2.run_query("""
        INSERT INTO category_translation
        VALUES ('categoria_de_ejemplo', 'example_category')
    """)
    print("T2 todavía no confirma: T1 no puede ver la fila nueva")
    filas = T1.run_query(contar)
    print(f"run_query retorna las filas: {filas}")
    T2.rollback()
    T1.commit()
