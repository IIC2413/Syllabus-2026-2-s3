"""
sesiones.py: script de apoyo para ejecutar transacciones concurrentes.
NO MODIFICAR ESTE ARCHIVO. Su solución va en p1.py, p2.py y p3.py.

Uso (desde la carpeta de la tarea):

    python3 sesiones.py --db bdd_t4 --verificar    # revisa la conexión y las tablas
    python3 sesiones.py --db bdd_t4 --ejemplo      # ejecuta ejemplo() de ejemplo.py
    python3 sesiones.py --db bdd_t4 --parte 1      # ejecuta parte_1() de p1.py
    python3 sesiones.py --db bdd_t4 --parte 2      # ejecuta parte_2() de p2.py
    python3 sesiones.py --db bdd_t4 --parte 3      # ejecuta parte_3() de p3.py

Cada ejecución muestra en pantalla las operaciones en el orden exacto en que se
ejecutaron, junto a la sesión que las ejecutó y sus resultados.
"""

import argparse
import datetime
import importlib.util
import os
import sys
import textwrap

import psycopg2


# =====================================================================
#  Sesiones y transacciones
# =====================================================================
#
#  Cada objeto Sesion es una conexión independiente al servidor PostgreSQL.
#  Sus tres operaciones son:
#
#      T1 = Sesion("T1")
#      filas = T1.run_query("SELECT ...")   # ejecuta SQL y retorna las filas
#      T1.commit()                          # confirma la transacción
#      T1.rollback()                        # deshace la transacción
#
#  La primera consulta de una sesión inicia su transacción. La transacción
#  queda abierta hasta commit() o rollback(). La consulta siguiente inicia
#  una transacción nueva automáticamente.
#
#  Todas las sesiones trabajan con el nivel de aislamiento por defecto de
#  PostgreSQL (read committed). Este script lo fija al abrir cada sesión y
#  detiene la ejecución si una consulta lo cambia.

NIVEL_AISLAMIENTO = "read committed"   # nivel por defecto de PostgreSQL
CONTROL_TRANSACCION = ("BEGIN", "START", "COMMIT", "END", "ROLLBACK", "ABORT")
MAX_FILAS = 10        # filas que se imprimen por cada resultado
ESPERA_LOCK = "5s"    # tiempo máximo que una operación espera por un lock

_estado = {"db": None, "paso": 0, "sesiones": []}


class ErrorEjecucion(Exception):
    """Una operación falló: la ejecución se detiene."""


def _log(texto=""):
    print(texto)


def _encabezado(sesion, operacion):
    _estado["paso"] += 1
    _log()
    _log(f"[{_estado['paso']:02d}] {sesion} > {operacion}")


def _texto(valor):
    if valor is None:
        return "NULL"
    valor = str(valor).replace("\n", " ")
    return valor if len(valor) <= 40 else valor[:37] + "..."


def _imprimir_tabla(columnas, filas):
    visibles = [[_texto(v) for v in fila] for fila in filas[:MAX_FILAS]]
    anchos = [max(len(c), *(len(f[i]) for f in visibles)) if visibles else len(c)
              for i, c in enumerate(columnas)]
    _log(("     " + " | ".join(c.ljust(a) for c, a in zip(columnas, anchos))).rstrip())
    _log("    -" + "-+-".join("-" * a for a in anchos) + "-")
    for fila in visibles:
        _log(("     " + " | ".join(v.ljust(a) for v, a in zip(fila, anchos))).rstrip())
    total = f"({len(filas)} fila{'' if len(filas) == 1 else 's'}"
    if len(filas) > MAX_FILAS:
        total += f", se muestran las primeras {MAX_FILAS}"
    _log("    " + total + ")")


def _abortar(sesion, error):
    mensaje = str(error).strip().splitlines()[0] if str(error).strip() else repr(error)
    _log(f"    !! ERROR en {sesion.nombre}: {mensaje}")
    codigo = getattr(error, "pgcode", None)
    if codigo == "55P03":
        _log("    !! Esta operación quedó esperando un lock que mantiene otra sesión.")
        _log("    !! Como las operaciones de su archivo se ejecutan una después de otra,")
        _log("    !! la otra sesión nunca alcanzaría a liberarlo: revise el orden de sus operaciones.")
    for otra in _estado["sesiones"]:
        otra._cerrar()
    raise ErrorEjecucion(mensaje)


class Sesion:
    """Una conexión propia a la base de datos, con su propia transacción."""

    def __init__(self, nombre):
        self.nombre = nombre
        self.abierta = False          # ¿hay una transacción en curso?
        self.conn = psycopg2.connect(dbname=_estado["db"])
        cursor = self.conn.cursor()
        cursor.execute("SET SESSION CHARACTERISTICS AS TRANSACTION ISOLATION LEVEL "
                       + NIVEL_AISLAMIENTO.upper())
        cursor.execute(f"SET lock_timeout = '{ESPERA_LOCK}'")
        self.conn.commit()
        _estado["sesiones"].append(self)

    def run_query(self, sql):
        """Ejecuta una consulta SQL. Retorna las filas como lista de tuplas
        (lista vacía si la consulta no retorna filas)."""
        sql = textwrap.dedent(sql).strip()
        _encabezado(self.nombre, "run query")
        _log(textwrap.indent(sql, "    "))
        lineas = [l for l in sql.splitlines() if l.strip() and not l.strip().startswith("--")]
        if not lineas:
            _abortar(self, "la consulta está vacía (¿falta completarla?)")
        # Las transacciones se controlan solo con commit() y rollback() de la sesión.
        for sentencia in "\n".join(lineas).split(";"):
            if sentencia.split() and sentencia.split()[0].upper() in CONTROL_TRANSACCION:
                _abortar(self, "no puede escribir BEGIN, COMMIT ni ROLLBACK dentro de una consulta. "
                               "Use las operaciones commit() y rollback() de la sesión")
        cursor = self.conn.cursor()
        self.abierta = True
        try:
            cursor.execute(sql)
            filas = cursor.fetchall() if cursor.description is not None else None
            # Control: la transacción debe seguir en el nivel de aislamiento de la tarea.
            control = self.conn.cursor()
            control.execute("SHOW transaction_isolation")
            nivel = control.fetchall()[0][0]
        except psycopg2.Error as error:
            _abortar(self, error)
        if nivel != NIVEL_AISLAMIENTO:
            _abortar(self, f"la transacción quedó con nivel de aislamiento '{nivel}'. La tarea "
                           f"debe resolverse en '{NIVEL_AISLAMIENTO}': no está permitido cambiarlo")
        if filas is None:
            afectadas = f" ({cursor.rowcount} fila(s) afectada(s))" if cursor.rowcount >= 0 else ""
            _log(f"    -> OK{afectadas}")
            return []
        _imprimir_tabla([columna[0] for columna in cursor.description], filas)
        return filas

    def commit(self):
        """Confirma la transacción en curso de esta sesión."""
        _encabezado(self.nombre, "commit")
        try:
            self.conn.commit()
        except psycopg2.Error as error:
            _abortar(self, error)
        self.abierta = False
        _log("    -> OK")

    def rollback(self):
        """Deshace la transacción en curso de esta sesión."""
        _encabezado(self.nombre, "rollback")
        self.conn.rollback()
        self.abierta = False
        _log("    -> OK")

    def _cerrar(self):
        if self.conn is not None:
            self.conn.rollback()
            self.conn.close()
            self.conn = None


# =====================================================================
#  Ejecución
# =====================================================================

TABLAS = ["customers", "sellers", "category_translation", "products",
          "orders", "order_items", "order_payments", "order_reviews"]


def _datos_servidor():
    conn = psycopg2.connect(dbname=_estado["db"])
    cursor = conn.cursor()
    cursor.execute("SHOW server_version")
    version = cursor.fetchall()[0][0].split()[0]
    cursor.execute("SHOW transaction_isolation")
    aislamiento = cursor.fetchall()[0][0]
    conn.rollback()
    return conn, version, aislamiento


def verificar():
    conn, version, aislamiento = _datos_servidor()
    print(f"Base de datos:        {_estado['db']}")
    print(f"Versión del servidor: PostgreSQL {version}")
    print(f"Nivel de aislamiento: {NIVEL_AISLAMIENTO} (lo fija este script en cada sesión)")
    print()
    cursor = conn.cursor()
    for tabla in TABLAS:
        try:
            cursor.execute(f"SELECT COUNT(*) FROM {tabla}")
            filas = cursor.fetchall()[0][0]
        except psycopg2.Error:
            conn.rollback()
            print(f"  {tabla:<22} NO EXISTE (ejecute schema.sql y load.sql)")
            continue
        aviso = "" if filas > 0 else "   <- VACÍA (ejecute load.sql)"
        print(f"  {tabla:<22} {filas:>7} filas{aviso}")
    conn.rollback()
    conn.close()
    if aislamiento != NIVEL_AISLAMIENTO:
        print(f"\nNota: su servidor está configurado con '{aislamiento}' como nivel por defecto. "
              f"No afecta a la tarea: este script fija '{NIVEL_AISLAMIENTO}' en cada sesión.")


def _ejecutar(funcion, titulo):
    conn, version, aislamiento = _datos_servidor()
    conn.close()
    _log("=" * 72)
    _log(titulo)
    _log(f"Fecha: {datetime.datetime.now():%Y-%m-%d %H:%M:%S} | Base de datos: {_estado['db']} | "
         f"PostgreSQL {version} | Aislamiento: {NIVEL_AISLAMIENTO}")
    _log("=" * 72)
    correcto = True
    try:
        funcion()
        if _estado["paso"] == 0:
            _log()
            _log("La función no ejecutó ninguna operación.")
    except ErrorEjecucion:
        correcto = False
        _log()
        _log("Ejecución detenida: se hizo ROLLBACK de todas las transacciones abiertas.")
    finally:
        for sesion in _estado["sesiones"]:
            if sesion.conn is not None and sesion.abierta:
                _log()
                _log(f"ADVERTENCIA: la sesión {sesion.nombre} terminó con una transacción abierta. "
                     "Se hizo ROLLBACK: sus cambios NO quedaron en la base de datos.")
            sesion._cerrar()
    return correcto


def _cargar(archivo, funcion, carpeta):
    """Importa <archivo>.py desde la carpeta indicada y retorna la función pedida."""
    ruta = os.path.join(carpeta, archivo + ".py")
    if not os.path.isfile(ruta):
        sys.exit(f"No se encontró el archivo {archivo}.py en la carpeta {carpeta}")
    sys.path.insert(0, carpeta)
    especificacion = importlib.util.spec_from_file_location(archivo, ruta)
    modulo = importlib.util.module_from_spec(especificacion)
    especificacion.loader.exec_module(modulo)
    if not hasattr(modulo, funcion):
        sys.exit(f"El archivo {archivo}.py no define la función {funcion}()")
    return getattr(modulo, funcion)


def main():
    # Los archivos p1.py, p2.py, p3.py y ejemplo.py hacen "from sesiones import Sesion":
    # deben recibir este mismo módulo, que se está ejecutando como programa principal.
    sys.modules["sesiones"] = sys.modules[__name__]
    parser = argparse.ArgumentParser(description="Tarea 4 - transacciones concurrentes")
    parser.add_argument("--db", default="bdd_t4", help="nombre de la base de datos (por defecto: bdd_t4)")
    parser.add_argument("--carpeta", default=os.path.dirname(os.path.abspath(__file__)),
                        help="carpeta donde están p1.py, p2.py y p3.py (por defecto: la de este script)")
    grupo = parser.add_mutually_exclusive_group(required=True)
    grupo.add_argument("--verificar", action="store_true", help="revisa la conexión y las tablas")
    grupo.add_argument("--ejemplo", action="store_true", help="ejecuta ejemplo() de ejemplo.py")
    grupo.add_argument("--parte", type=int, choices=[1, 2, 3], help="ejecuta parte_N() de pN.py")
    args = parser.parse_args()
    _estado["db"] = args.db

    try:
        if args.verificar:
            verificar()
            correcto = True
        elif args.ejemplo:
            correcto = _ejecutar(_cargar("ejemplo", "ejemplo", args.carpeta), "EJEMPLO")
        else:
            funcion = _cargar(f"p{args.parte}", f"parte_{args.parte}", args.carpeta)
            correcto = _ejecutar(funcion, f"PARTE {args.parte}")
    except psycopg2.OperationalError as error:
        print(f"No se pudo conectar a la base de datos '{args.db}':\n  {str(error).strip()}")
        print("Revise que el servidor PostgreSQL esté corriendo y que la base de datos exista "
              "(createdb). Si su instalación requiere usuario y contraseña, defina las variables "
              "de entorno PGUSER, PGPASSWORD y PGHOST.")
        correcto = False
    sys.exit(0 if correcto else 1)


if __name__ == "__main__":
    main()
