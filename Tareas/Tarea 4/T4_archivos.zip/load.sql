-- =====================================================================
-- IIC2413 - Bases de Datos - Tarea 4
-- load.sql: puebla las tablas con los archivos .csv de la carpeta data/.
--
-- Uso (desde la carpeta de la tarea, DESPUÉS de schema.sql):
--     psql -d bdd_t4 -f load.sql
--
-- Las rutas data/... son relativas a la carpeta desde donde se ejecuta psql.
-- =====================================================================

\set ON_ERROR_STOP on
\encoding UTF8

BEGIN;

-- Si las tablas ya tenían datos, se vacían antes de volver a cargar.
TRUNCATE order_reviews, order_payments, order_items, orders,
         products, category_translation, sellers, customers;

-- Las tablas "padre" se cargan antes que las tablas que las referencian.

\copy customers FROM 'data/olist_customers_dataset.csv' WITH (FORMAT csv, HEADER true)

\copy sellers FROM 'data/olist_sellers_dataset.csv' WITH (FORMAT csv, HEADER true)

\copy category_translation FROM 'data/product_category_name_translation.csv' WITH (FORMAT csv, HEADER true)

-- products se carga primero como texto y luego se convierte, para aceptar
-- tanto "40" como "40.0" en las columnas enteras del archivo .csv.
CREATE TEMP TABLE products_csv (
    product_id TEXT, product_category_name TEXT, product_name_length TEXT,
    product_description_length TEXT, product_photos_qty TEXT, product_weight_g TEXT,
    product_length_cm TEXT, product_height_cm TEXT, product_width_cm TEXT
) ON COMMIT DROP;

\copy products_csv FROM 'data/olist_products_dataset.csv' WITH (FORMAT csv, HEADER true)

INSERT INTO products
SELECT product_id,
       NULLIF(product_category_name, ''),
       NULLIF(product_name_length, '')::numeric::integer,
       NULLIF(product_description_length, '')::numeric::integer,
       NULLIF(product_photos_qty, '')::numeric::integer,
       NULLIF(product_weight_g, '')::real,
       NULLIF(product_length_cm, '')::real,
       NULLIF(product_height_cm, '')::real,
       NULLIF(product_width_cm, '')::real
FROM products_csv;

\copy orders FROM 'data/olist_orders_dataset.csv' WITH (FORMAT csv, HEADER true)

\copy order_items FROM 'data/olist_order_items_dataset.csv' WITH (FORMAT csv, HEADER true)

\copy order_payments FROM 'data/olist_order_payments_dataset.csv' WITH (FORMAT csv, HEADER true)

\copy order_reviews FROM 'data/olist_order_reviews_dataset.csv' WITH (FORMAT csv, HEADER true)

COMMIT;

ANALYZE;

-- Resumen de la carga
SELECT tabla, filas
FROM (
              SELECT 1 AS orden, 'customers' AS tabla, COUNT(*) AS filas FROM customers
    UNION ALL SELECT 2, 'sellers', COUNT(*) FROM sellers
    UNION ALL SELECT 3, 'category_translation', COUNT(*) FROM category_translation
    UNION ALL SELECT 4, 'products', COUNT(*) FROM products
    UNION ALL SELECT 5, 'orders', COUNT(*) FROM orders
    UNION ALL SELECT 6, 'order_items', COUNT(*) FROM order_items
    UNION ALL SELECT 7, 'order_payments', COUNT(*) FROM order_payments
    UNION ALL SELECT 8, 'order_reviews', COUNT(*) FROM order_reviews
) AS resumen
ORDER BY orden;
