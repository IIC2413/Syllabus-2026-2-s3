"""
Parte 3: El caso del recargo logístico perdido #2

Ejecutar con:  python3 sesiones.py --db bdd_t4 --parte 3
"""

from sesiones import Sesion

def parte_3():
    pass
