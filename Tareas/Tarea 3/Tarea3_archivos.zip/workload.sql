-- ===== 01 =====
SELECT order_id, order_date, status, total_amount
FROM orders
WHERE user_id = 92696
ORDER BY order_date DESC, order_id DESC
LIMIT 20;

-- ===== 02 =====
SELECT u.user_id, u.email, t.n_orders, t.total_spent
FROM users u
JOIN (SELECT user_id, COUNT(*) AS n_orders, SUM(total_amount) AS total_spent
      FROM orders
      WHERE order_date >= '2025-01-01' AND order_date < '2026-01-01'
      GROUP BY user_id) t ON t.user_id = u.user_id
WHERE u.email = 'gisela.novak27182@readers.net';

-- ===== 03 =====
SELECT COUNT(*) AS orders, SUM(oi.quantity) AS units,
       COUNT(DISTINCT o.user_id) AS buyers
FROM order_items oi
JOIN orders o ON o.order_id = oi.order_id
WHERE oi.book_id = 19436
  AND o.order_date >= '2025-01-01' AND o.order_date < '2026-01-01';

-- ===== 04 =====
SELECT date_trunc('month', o.order_date) AS month,
       SUM(oi.quantity * oi.unit_price) AS revenue
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
JOIN books b ON b.book_id = oi.book_id
WHERE o.status = 'delivered'
  AND b.genre = 'poetry'
  AND o.order_date >= '2025-01-01' AND o.order_date < '2026-01-01'
GROUP BY date_trunc('month', o.order_date)
ORDER BY month;

-- ===== 05 =====
SELECT user_id, is_premium, country
FROM users
WHERE email = 'Paula.sepulveda152267@lectura.cl';

-- ===== 06 =====
SELECT review_id, user_id, rating, review_text, review_date
FROM reviews
WHERE book_id = 9458
ORDER BY review_date DESC, review_id DESC
LIMIT 10;

-- ===== 07 =====
SELECT b.genre, SUM(oi.quantity * oi.unit_price) AS revenue,
       SUM(oi.quantity) AS units
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
JOIN books b ON b.book_id = oi.book_id
WHERE o.status = 'delivered'
  AND o.order_date >= '2025-04-01' AND o.order_date < '2025-07-01'
GROUP BY b.genre
ORDER BY revenue DESC, b.genre;

-- ===== 08 =====
SELECT status, COUNT(*) AS n, SUM(total_amount) AS amount
FROM orders
WHERE DATE(order_date) = '2024-12-20'
GROUP BY status
ORDER BY status;

-- ===== 09 =====
SELECT o.order_id, o.user_id, o.order_date, oi.book_id, oi.quantity
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
WHERE o.user_id = 4321 OR oi.book_id = 1234
ORDER BY o.order_id, oi.book_id;

-- ===== 10 =====
SELECT b.book_id, b.title, a.name AS author, b.price,
       COALESCE(SUM(i.stock_count), 0) AS stock
FROM books b
JOIN authors a ON a.author_id = b.author_id
LEFT JOIN inventory i ON i.book_id = b.book_id
WHERE b.book_id = 29781
GROUP BY b.book_id, b.title, a.name, b.price;

-- ===== 11 =====
SELECT book_id, COUNT(*) AS n_orders, SUM(quantity) AS units
FROM order_items
GROUP BY book_id
HAVING book_id IN (SELECT book_id FROM books WHERE author_id = 357)
ORDER BY book_id;

-- ===== 12 =====
SELECT b.book_id, b.title, b.genre, b.price
FROM books b
WHERE b.publication_year = 2017
  AND b.page_count >= 500
  AND b.price > (SELECT AVG(b2.price) FROM books b2 WHERE b2.genre = b.genre)
ORDER BY b.book_id;

-- ===== 13 =====
SELECT b.book_id, b.title, SUM(oi.quantity) AS units
FROM orders o
JOIN order_items oi ON oi.order_id = o.order_id
JOIN books b ON b.book_id = oi.book_id
WHERE o.status = 'delivered'
  AND o.order_date >= '2025-11-01' AND o.order_date < '2025-12-01'
GROUP BY b.book_id, b.title
ORDER BY units DESC, b.book_id
LIMIT 10;

-- ===== 14 =====
SELECT oi.book_id, b.title, oi.quantity, oi.unit_price
FROM order_items oi
JOIN books b ON b.book_id = oi.book_id
WHERE oi.order_id = 1234567
ORDER BY oi.book_id;

-- ===== 15 =====
SELECT order_id, user_id, order_date, total_amount
FROM orders
WHERE status = 'pending'
  AND order_date >= '2025-06-16' AND order_date < '2025-06-23'
ORDER BY order_date DESC, order_id DESC
LIMIT 50;
