"""
Aplica sus índices desde indexes.sql (máximo 3 CREATE INDEX).

Antes de crearlos, borra los índices creados antes sobre las tablas
de la librería (nunca los de PRIMARY KEY ni UNIQUE). Así la base queda
exactamente con los índices de su archivo y puede editarlo y volver a
correr el script las veces que quiera. Al final corre ANALYZE.

Uso:
    python3 apply_indexes.py --db bdd_t3 --file indexes.sql

indexes.sql solo puede tener sentencias CREATE INDEX (y, si quiere, ANALYZE).
"""

import argparse
import re
import sys
from pathlib import Path

from run_workload import add_connection_args, connect

TABLES = ["users", "authors", "books", "inventory", "orders", "order_items", "reviews"]
MAX_INDEXES = 3

SECONDARY_INDEXES = """
SELECT t.relname AS tabla, i.relname AS indice, pg_size_pretty(pg_relation_size(i.oid)) AS tamano
FROM pg_index x
JOIN pg_class i ON i.oid = x.indexrelid
JOIN pg_class t ON t.oid = x.indrelid
JOIN pg_namespace n ON n.oid = t.relnamespace
WHERE n.nspname = 'public'
  AND t.relname IN ({tables})
  AND NOT EXISTS (SELECT 1 FROM pg_constraint c WHERE c.conindid = x.indexrelid)
ORDER BY t.relname, i.relname
""".format(tables=", ".join(f"'{t}'" for t in TABLES))


def split_statements(text):
    """Separa el archivo en sentencias por ';', ignorando comentarios (-- y /* */)
    y lo que esté entre comillas simples."""
    stmts, buf = [], []
    i, n, in_quote = 0, len(text), False
    while i < n:
        ch = text[i]
        if in_quote:
            buf.append(ch)
            if ch == "'":
                if i + 1 < n and text[i + 1] == "'":
                    buf.append("'")
                    i += 2
                    continue
                in_quote = False
            i += 1
        elif ch == "'":
            in_quote = True
            buf.append(ch)
            i += 1
        elif text.startswith("--", i):
            j = text.find("\n", i)
            i = n if j == -1 else j
        elif text.startswith("/*", i):
            j = text.find("*/", i + 2)
            i = n if j == -1 else j + 2
            buf.append(" ")
        elif ch == ";":
            stmts.append("".join(buf).strip())
            buf = []
            i += 1
        else:
            buf.append(ch)
            i += 1
    stmts.append("".join(buf).strip())
    return [s for s in stmts if s]


def check(stmts, max_indexes):
    indexes = []
    for s in stmts:
        if re.match(r"(?is)^CREATE\s+(UNIQUE\s+)?INDEX\b", s):
            m = re.search(r"(?is)\bON\s+(?:ONLY\s+)?([\w.\"]+)", s)
            table = m.group(1).replace('"', "").split(".")[-1].lower() if m else None
            if table not in TABLES:
                sys.exit(f"Este índice no es sobre una tabla de la librería:\n  {s}\n"
                         "Los índices sobre su vista materializada van en matview.sql.")
            indexes.append(s)
        elif re.match(r"(?is)^ANALYZE\b", s):
            continue
        else:
            sys.exit(f"indexes.sql solo puede tener CREATE INDEX (y ANALYZE). Encontré:\n  {s}")
    if not indexes:
        sys.exit("No encontré ningún CREATE INDEX en el archivo.")
    if len(indexes) > max_indexes:
        sys.exit(f"El archivo tiene {len(indexes)} índices y el máximo permitido es {max_indexes}.")
    return indexes


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_connection_args(ap)
    ap.add_argument("--file", type=Path, default=Path("indexes.sql"),
                    help="archivo con los índices (por defecto: indexes.sql)")
    args = ap.parse_args()

    if not args.file.exists():
        sys.exit(f"No encontré {args.file}. Cree ese archivo con sus CREATE INDEX (máximo {MAX_INDEXES}).")
    indexes = check(split_statements(args.file.read_text(encoding="utf-8")), MAX_INDEXES)

    conn = connect(args)
    conn.autocommit = True
    cur = conn.cursor()

    cur.execute(SECONDARY_INDEXES)
    old = cur.fetchall()
    for _, name, _ in old:
        cur.execute(f'DROP INDEX IF EXISTS public."{name}"')
    if old:
        print(f"Borré {len(old)} índice(s) creados antes: {', '.join(r[1] for r in old)}")

    print(f"Creando {len(indexes)} índice(s) de {args.file}...")
    for s in indexes:
        try:
            cur.execute(s)
        except Exception as e:
            sys.exit(f"Error al crear el índice:\n  {s}\n{e}")
    cur.execute("ANALYZE " + ", ".join(TABLES))

    cur.execute(SECONDARY_INDEXES)
    print("\nÍndices actuales (además de PK y UNIQUE):")
    for table, name, size in cur.fetchall():
        print(f"  {table:<12} {name:<30} {size:>10}")
    print("\nListo. Ahora vuelva a medir con run_workload.py.")
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
