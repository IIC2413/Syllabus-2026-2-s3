"""
Aplica la vista materializada desde matview.sql.

matview.sql debe tener exactamente 1 CREATE MATERIALIZED VIEW y, si quiere,
1 CREATE INDEX sobre esa vista (y nada más, salvo ANALYZE).

Antes de crearla, borra las vistas materializadas creadas antes, así
puede editar el archivo y volver a correr el script las veces que quiera.
Al final corre ANALYZE sobre la vista y muestra cuántas filas tiene y cuánto pesa.

Uso:
    python3 apply_matview.py --db bdd_t3 --file matview.sql
"""

import argparse
import re
import sys
from pathlib import Path

from apply_indexes import split_statements
from run_workload import add_connection_args, connect

EXISTING = """
SELECT matviewname FROM pg_matviews WHERE schemaname = 'public' ORDER BY matviewname
"""


def check(stmts):
    views, indexes = [], []
    for s in stmts:
        m = re.match(r"(?is)^CREATE\s+MATERIALIZED\s+VIEW\s+(?:IF\s+NOT\s+EXISTS\s+)?([\w.\"]+)", s)
        if m:
            views.append((m.group(1).replace('"', "").split(".")[-1].lower(), s))
        elif re.match(r"(?is)^CREATE\s+(UNIQUE\s+)?INDEX\b", s):
            on = re.search(r"(?is)\bON\s+(?:ONLY\s+)?([\w.\"]+)", s)
            indexes.append((on.group(1).replace('"', "").split(".")[-1].lower() if on else None, s))
        elif re.match(r"(?is)^ANALYZE\b", s):
            continue
        else:
            sys.exit("matview.sql solo puede tener 1 CREATE MATERIALIZED VIEW, "
                     f"1 CREATE INDEX sobre ella y ANALYZE. Encontré:\n  {s}")
    if len(views) != 1:
        sys.exit(f"matview.sql debe tener exactamente 1 CREATE MATERIALIZED VIEW (tiene {len(views)}).")
    view_name = views[0][0]
    if len(indexes) > 1:
        sys.exit(f"matview.sql puede tener a lo más 1 índice sobre la vista (tiene {len(indexes)}).")
    for table, s in indexes:
        if table != view_name:
            sys.exit(f"El índice de matview.sql debe ser sobre la vista {view_name}:\n  {s}\n"
                     "Los índices sobre las tablas van en indexes.sql.")
    return view_name, views[0][1], [s for _, s in indexes]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_connection_args(ap)
    ap.add_argument("--file", type=Path, default=Path("matview.sql"),
                    help="archivo con la vista (por defecto: matview.sql)")
    args = ap.parse_args()

    if not args.file.exists():
        sys.exit(f"No encontré {args.file}. Cree ese archivo con su CREATE MATERIALIZED VIEW.")
    view_name, view_sql, index_sql = check(split_statements(args.file.read_text(encoding="utf-8")))

    conn = connect(args)
    conn.autocommit = True
    cur = conn.cursor()

    cur.execute(EXISTING)
    old = [r[0] for r in cur.fetchall()]
    for name in old:
        cur.execute(f'DROP MATERIALIZED VIEW IF EXISTS public."{name}"')
    if old:
        print(f"Borré la(s) vista(s) creadas antes: {', '.join(old)}")

    print(f"Creando la vista {view_name}...")
    for s in [view_sql] + index_sql:
        try:
            cur.execute(s)
        except Exception as e:
            sys.exit(f"Error al ejecutar:\n  {s}\n{e}")
    cur.execute(f'ANALYZE public."{view_name}"')

    cur.execute(f'SELECT count(*), pg_size_pretty(pg_total_relation_size(\'public."{view_name}"\')) '
                f'FROM public."{view_name}"')
    rows, size = cur.fetchall()[0]
    n_rows = f"{int(rows):,}".replace(",", ".")
    print(f"\nVista {view_name}: {n_rows} filas, {size} (incluye su índice, si tiene)")
    print(f"Índice sobre la vista: {'sí' if index_sql else 'no'}")
    print("\nListo. Ahora reescriba en workload_after.sql las consultas que la usan, "
          "y verifique con check_results.py.")
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
