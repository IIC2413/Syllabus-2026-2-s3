"""
Verifica que cada consulta reescrita devuelve EXACTAMENTE el mismo resultado
que la original (mismas filas, en el mismo orden).

Compara workload.sql con workload_after.sql etiqueta por etiqueta. Solo
ejecuta las consultas que cambió; las demás las cuenta como "sin cambios".
Para que la comparación tenga sentido, la base debe tener aplicados sus
índices y su vista (las reescrituras pueden usarla).

Uso:
    python3 check_results.py --db bdd_t3 --original workload.sql --rewritten workload_after.sql

Termina con código 1 si alguna reescritura da error o no devuelve lo mismo.
"""

import argparse
import re
import sys
from pathlib import Path

from run_workload import add_connection_args, connect, parse_workload


def normalize(sql):
    return re.sub(r"\s+", " ", sql).strip().lower()


def run(conn, cur, sql):
    try:
        cur.execute(sql)
        rows = cur.fetchall() if cur.description is not None else []
        return rows, None
    except Exception as e:
        return None, str(e).strip()
    finally:
        conn.rollback()


def short(row, width=110):
    text = " | ".join(str(v) for v in row)
    return text if len(text) <= width else text[:width - 3] + "..."


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_connection_args(ap)
    ap.add_argument("--original", type=Path, default=Path("workload.sql"))
    ap.add_argument("--rewritten", type=Path, default=Path("workload_after.sql"))
    args = ap.parse_args()

    if not args.rewritten.exists():
        sys.exit(f"No encontré {args.rewritten}. Copie {args.original} con ese nombre y "
                 "reescriba ahí las consultas, manteniendo las etiquetas.")
    original = parse_workload(args.original.read_text(encoding="utf-8"), args.original)
    rewritten = dict(parse_workload(args.rewritten.read_text(encoding="utf-8"), args.rewritten))
    labels = [label for label, _ in original]
    if set(labels) != set(rewritten):
        missing = sorted(set(labels) - set(rewritten))
        extra = sorted(set(rewritten) - set(labels))
        sys.exit("Las etiquetas no coinciden."
                 + (f" Faltan en {args.rewritten}: {', '.join(missing)}." if missing else "")
                 + (f" Sobran en {args.rewritten}: {', '.join(extra)}." if extra else ""))

    conn = connect(args)
    conn.autocommit = False
    cur = conn.cursor()
    print(f"Comparando {args.original} con {args.rewritten}\n")
    same = changed = bad = errors = 0
    for label, sql in original:
        new_sql = rewritten[label]
        if normalize(sql) == normalize(new_sql):
            same += 1
            continue
        changed += 1
        rows_o, err_o = run(conn, cur, sql)
        rows_r, err_r = run(conn, cur, new_sql)
        if err_o:
            print(f"  {label}: ERROR en la consulta original: {err_o}")
            errors += 1
        elif err_r:
            print(f"  {label}: ERROR en la reescrita: {err_r}")
            errors += 1
        elif rows_o == rows_r:
            print(f"  {label}: IGUAL ({len(rows_o)} {'fila' if len(rows_o) == 1 else 'filas'})")
        else:
            bad += 1
            if sorted(map(repr, rows_o)) == sorted(map(repr, rows_r)):
                print(f"  {label}: DISTINTO: mismas filas, pero en otro orden (revise el ORDER BY)")
            elif len(rows_o) != len(rows_r):
                print(f"  {label}: DISTINTO: la original devuelve {len(rows_o)} filas y la reescrita {len(rows_r)}")
            else:
                i = next(k for k, (a, b) in enumerate(zip(rows_o, rows_r)) if a != b)
                print(f"  {label}: DISTINTO desde la fila {i + 1}:")
                print(f"      original:  {short(rows_o[i])}")
                print(f"      reescrita: {short(rows_r[i])}")
    cur.close()
    conn.close()

    print(f"\nReescritas: {changed}  |  iguales: {changed - bad - errors}  |  distintas: {bad}  |  "
          f"con error: {errors}  |  sin cambios: {same}")
    if bad or errors:
        print("Hay reescrituras con error o que no devuelven lo mismo: corríjalas antes de medir.")
        sys.exit(1)


if __name__ == "__main__":
    main()
