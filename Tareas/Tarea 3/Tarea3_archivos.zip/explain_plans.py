"""
Guarda el plan de ejecución de cada consulta del workload, un archivo por consulta.

Usa EXPLAIN (ANALYZE, COSTS OFF, BUFFERS OFF): ejecuta la consulta de verdad y
muestra, para cada paso del plan, el tiempo real y las filas reales.

Uso:
    python3 explain_plans.py --db bdd_t3 --out plans_base
    python3 explain_plans.py --db bdd_t3 --out plans_indices
    python3 explain_plans.py --db bdd_t3 --out plans_base --labels 02 09

Cada archivo <out>/<etiqueta>.txt trae la consulta y su plan.
"""

import argparse
import re
import sys
from pathlib import Path

from run_workload import add_connection_args, connect, parse_workload

EXPLAIN = "EXPLAIN (ANALYZE, COSTS OFF, BUFFERS OFF) "


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_connection_args(ap)
    ap.add_argument("--workload", type=Path, default=Path("workload.sql"),
                    help="archivo SQL (por defecto: workload.sql)")
    ap.add_argument("--out", type=Path, default=Path("plans"),
                    help="carpeta donde guardar los planes (por defecto: plans)")
    ap.add_argument("--labels", nargs="*", default=None,
                    help="solo estas consultas (por ejemplo: --labels 02 09); por defecto, todas")
    args = ap.parse_args()

    if not args.workload.exists():
        sys.exit(f"No encontré el workload: {args.workload}")
    queries = parse_workload(args.workload.read_text(encoding="utf-8"), args.workload)
    if args.labels:
        wanted = set(args.labels)
        unknown = wanted - {label for label, _ in queries}
        if unknown:
            sys.exit(f"No existen en el workload: {', '.join(sorted(unknown))}")
        queries = [(l, s) for l, s in queries if l in wanted]

    args.out.mkdir(parents=True, exist_ok=True)
    conn = connect(args)
    conn.autocommit = False
    cur = conn.cursor()
    print(f"Guardando {len(queries)} {'plan' if len(queries) == 1 else 'planes'} en {args.out}/")
    for label, sql in queries:
        try:
            cur.execute(EXPLAIN + sql)
            plan = "\n".join(r[0] for r in cur.fetchall())
        except Exception as e:
            conn.rollback()
            print(f"  {label}: ERROR {e}", file=sys.stderr)
            continue
        conn.rollback()
        (args.out / f"{label}.txt").write_text(
            f"-- Consulta {label}\n{sql};\n\n{plan}\n", encoding="utf-8")
        m = re.search(r"Execution Time: ([\d.]+) ms", plan)
        print(f"  {label}: {m.group(1) + ' ms' if m else 'listo'}")
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
