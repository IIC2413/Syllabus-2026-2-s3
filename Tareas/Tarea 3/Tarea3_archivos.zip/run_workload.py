"""
Mide el tiempo del workload. Es la medición OFICIAL de la tarea.

Corre el workload 2 veces seguidas (la primera calienta la caché) y guarda
los tiempos por consulta de la ÚLTIMA corrida.

Uso:
    python3 run_workload.py --db bdd_t3 --csv tiempos_base.csv

Opciones:
    --workload <archivo>  correr otro archivo (por ejemplo workload_after.sql)
    --csv <archivo>       guardar los tiempos por consulta (una fila por consulta)
    --runs <n>            cuántas corridas hacer (por defecto 2)
"""

import argparse
import re
import sys
import time
from pathlib import Path


HEADER_RE = re.compile(r"^--\s*=====\s*(\S+)\s*=====\s*$", re.MULTILINE)


def split_first_statement(sql):
    """Separa sql en (primera sentencia, lo que queda después de su ';').
    Ignora los ';' dentro de comillas o comentarios. Lo que queda después se
    devuelve sin comentarios ni espacios: '' si no había nada más."""
    i, n = 0, len(sql)
    while i < n:
        ch = sql[i]
        if ch in "'\"":
            j = i + 1
            while j < n:
                if sql[j] == ch:
                    if j + 1 < n and sql[j + 1] == ch:
                        j += 2
                        continue
                    break
                j += 1
            i = j + 1
        elif sql.startswith("--", i):
            j = sql.find("\n", i)
            i = n if j == -1 else j
        elif sql.startswith("/*", i):
            j = sql.find("*/", i + 2)
            i = n if j == -1 else j + 2
        elif ch == ";":
            rest = re.sub(r"--[^\n]*|/\*.*?\*/", " ", sql[i + 1:], flags=re.S).strip()
            return sql[:i].rstrip(), rest
        else:
            i += 1
    return sql.strip(), ""


def parse_workload(text, source="el archivo"):
    """Devuelve pares (etiqueta, sql) en el orden del archivo. La etiqueta es
    lo que va entre `-- =====` y `=====`. Si una etiqueta se repite o un bloque
    tiene algo más que una consulta, termina con un mensaje que lo explica."""
    hits = list(HEADER_RE.finditer(text))
    out, seen = [], set()
    for i, m in enumerate(hits):
        label = m.group(1)
        if label in seen:
            sys.exit(f"La etiqueta {label} aparece más de una vez en {source}. "
                     "Cada consulta debe aparecer una sola vez.")
        seen.add(label)
        start = m.end()
        end = hits[i + 1].start() if i + 1 < len(hits) else len(text)
        block = text[start:end]
        stmt = "\n".join(
            ln for ln in block.splitlines()
            if ln.strip() and not ln.strip().startswith("--")
        ).strip()
        stmt, extra = split_first_statement(stmt)
        if extra:
            sys.exit(f"La consulta {label} de {source} tiene texto después de su ';':\n"
                     f"  {extra.splitlines()[0][:100]}\n"
                     "Cada bloque debe tener una sola consulta. Borre lo que sobra.")
        if stmt:
            out.append((label, stmt))
    return out


def is_write(sql):
    return sql.lstrip().split(None, 1)[0].upper() in {"UPDATE", "INSERT", "DELETE"}


def connect(args):
    try:
        import psycopg2
    except ImportError:
        sys.exit("Falta psycopg2. Instálelo con:  pip install psycopg2-binary")
    return psycopg2.connect(dbname=args.db, host=args.host, port=args.port,
                            user=args.user, password=args.password)


def add_connection_args(ap):
    ap.add_argument("--db", required=True, help="nombre de la base (por ejemplo bdd_t3)")
    ap.add_argument("--host", default="localhost")
    ap.add_argument("--port", default=5432, type=int)
    ap.add_argument("--user", default=None)
    ap.add_argument("--password", default=None)


def run_once(conn, queries):
    """Corre todas las consultas en una transacción que al final se deshace."""
    conn.autocommit = False
    cur = conn.cursor()
    timings = []
    t_start = time.perf_counter()
    for label, sql in queries:
        wrote = is_write(sql)
        if wrote:
            cur.execute("SAVEPOINT sp_run")
        t0 = time.perf_counter()
        try:
            cur.execute(sql)
            if cur.description is not None:
                cur.fetchall()
        except Exception as e:
            conn.rollback()
            print(f"  ERROR en {label}: {e}", file=sys.stderr)
            timings.append((label, float("nan")))
            continue
        elapsed = time.perf_counter() - t0
        if wrote:
            cur.execute("ROLLBACK TO SAVEPOINT sp_run")
        timings.append((label, elapsed))
    conn.rollback()
    cur.close()
    return time.perf_counter() - t_start, timings


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    add_connection_args(ap)
    ap.add_argument("--workload", type=Path, default=Path("workload.sql"),
                    help="archivo SQL a correr (por defecto: workload.sql)")
    ap.add_argument("--csv", type=Path, default=None,
                    help="si se indica, guarda los tiempos por consulta en este CSV")
    ap.add_argument("--runs", type=int, default=2,
                    help="cuántas corridas hacer; se reporta la última (por defecto 2)")
    args = ap.parse_args()

    if not args.workload.exists():
        sys.exit(f"No encontré el workload: {args.workload}")
    queries = parse_workload(args.workload.read_text(encoding="utf-8"), args.workload)
    if not queries:
        sys.exit("No encontré consultas en el archivo del workload.")

    conn = connect(args)
    print(f"Conectado a {args.db}. Corriendo {len(queries)} consultas de {args.workload}, "
          f"{args.runs} {'vez' if args.runs == 1 else 'veces'}.")
    for run in range(1, args.runs + 1):
        t_total, timings = run_once(conn, queries)
        print(f"  corrida {run}: {t_total * 1000:.0f} ms")
    conn.close()

    print()
    print(f"  >>>  T_workload = {t_total * 1000:.0f} ms  (última corrida)  <<<")
    print()

    if args.csv:
        with open(args.csv, "w", encoding="utf-8") as f:
            f.write("label,elapsed_ms\n")
            for label, elapsed in timings:
                f.write(f"{label},{elapsed * 1000:.3f}\n")
        print(f"Tiempos por consulta guardados en {args.csv}")


if __name__ == "__main__":
    main()
