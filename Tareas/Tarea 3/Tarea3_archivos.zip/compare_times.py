"""
Compara los tiempos por consulta entre dos o más mediciones de run_workload.py.

El primer archivo es la referencia (normalmente la línea base). Para cada
archivo siguiente muestra, por consulta y en total:
  ms        el tiempo medido
  speedup   cuántas veces más rápido que la referencia (54.0x = 54 veces)
  mejora    lo mismo en porcentaje: +100% = el doble de rápido,
            +5300% = 54 veces más rápido, negativo = más lento

Uso:
    python3 compare_times.py tiempos_base.csv tiempos_indices.csv
    python3 compare_times.py tiempos_base.csv tiempos_indices.csv tiempos_vista.csv tiempos_final.csv
    python3 compare_times.py --sort tiempos_base.csv tiempos_indices.csv   # ordena por tiempo base
"""

import argparse
import csv
import math
import sys
from pathlib import Path


def load(path):
    times = {}
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            times[row["label"]] = float(row["elapsed_ms"])
    if not times:
        sys.exit(f"{path} no tiene tiempos.")
    return times


def short_name(path):
    stem = Path(path).stem
    return stem[len("tiempos_"):] if stem.startswith("tiempos_") and len(stem) > 8 else stem


def fmt_ms(x):
    return "error" if math.isnan(x) else f"{x:.1f}"


def fmt_speedup(ref, x):
    if math.isnan(ref) or math.isnan(x) or x <= 0:
        return "-"
    return f"{ref / x:.1f}x"


def fmt_mejora(ref, x):
    if math.isnan(ref) or math.isnan(x) or x <= 0:
        return "-"
    return f"{(ref / x - 1) * 100:+.0f}%"


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("csv", nargs="+", help="archivos CSV de run_workload.py; el primero es la referencia")
    ap.add_argument("--sort", action="store_true",
                    help="ordenar las consultas de mayor a menor tiempo en la referencia")
    args = ap.parse_args()
    if len(args.csv) < 2:
        sys.exit("Necesito al menos dos archivos: la referencia y uno para comparar.")

    data = [load(p) for p in args.csv]
    names = [short_name(p) for p in args.csv]
    ref = data[0]
    labels = list(ref)
    for p, d in zip(args.csv[1:], data[1:]):
        missing = [l for l in labels if l not in d]
        if missing:
            sys.exit(f"{p} no tiene las consultas {', '.join(missing)}. ¿Es del mismo workload?")
    if args.sort:
        labels.sort(key=lambda l: -ref[l] if not math.isnan(ref[l]) else 0)

    head1 = f"{'consulta':<9}{names[0]:>12}"
    head2 = f"{'':<9}{'ms':>12}"
    for n in names[1:]:
        head1 += f"   {n:>32}"
        head2 += f"   {'ms':>10}{'speedup':>10}{'mejora':>12}"
    print(f"Comparación contra {args.csv[0]}\n")
    print(head1)
    print(head2)
    print("-" * len(head2))

    def row(label, values):
        line = f"{label:<9}{fmt_ms(values[0]):>12}"
        for v in values[1:]:
            line += f"   {fmt_ms(v):>10}{fmt_speedup(values[0], v):>10}{fmt_mejora(values[0], v):>12}"
        return line

    for l in labels:
        print(row(l, [d[l] for d in data]))
    totals = [sum(v for v in d.values() if not math.isnan(v)) for d in data]
    print("-" * len(head2))
    print(row("TOTAL", totals))


if __name__ == "__main__":
    main()
