# Tarea 3 — referencia de los scripts

Este archivo explica qué hace cada script, sus opciones y qué hacer si algo falla. Todos los scripts muestran su ayuda con `--help` (por ejemplo, `python3 run_workload.py --help`).

## Opciones comunes de conexión

Los scripts que se conectan a la base aceptan:

| Opción | Por defecto | Para qué |
| --- | --- | --- |
| `--db` | (obligatoria) | Nombre de la base, por ejemplo `bdd_t3` |
| `--host` | `localhost` | Servidor de PostgreSQL |
| `--port` | `5432` | Puerto |
| `--user` | su usuario del sistema | Usuario de PostgreSQL |
| `--password` | ninguna | Contraseña, si su instalación la pide |

## run_workload.py

Mide el workload. Es la medición oficial de la tarea.

- Corre todas las consultas del archivo 2 veces seguidas y reporta la **última** corrida. La primera sirve para calentar la caché.
- Imprime el tiempo total de cada corrida y el final (`T_workload`).
- Con `--csv`, guarda el tiempo de cada consulta (columnas `label,elapsed_ms`).
- Corre todo dentro de una transacción que al final se deshace, así que no modifica la base.

| Opción | Por defecto |
| --- | --- |
| `--workload` | `workload.sql` |
| `--csv` | no guarda CSV |
| `--runs` | `2` |

## explain_plans.py

Guarda el plan de ejecución de cada consulta, un archivo por consulta (`01.txt`, `02.txt`, etc.), con la consulta y su plan.

- Usa `EXPLAIN (ANALYZE, COSTS OFF, BUFFERS OFF)`: ejecuta la consulta de verdad y muestra, para cada paso del plan, el tiempo real y las filas reales, sin costos estimados ni buffers.

| Opción | Por defecto |
| --- | --- |
| `--workload` | `workload.sql` |
| `--out` | `plans` |
| `--labels` | todas (por ejemplo, `--labels 02 09` guarda solo esas dos) |

## apply_indexes.py

Aplica sus índices desde `indexes.sql`.

- El archivo solo puede contener sentencias `CREATE INDEX` (y, opcionalmente, `ANALYZE`), con un **máximo de 3** índices.
- Antes de crear los índices, borra los que haya creado antes sobre las tablas de la librería (nunca los de `PRIMARY KEY` ni `UNIQUE`). Así la base queda exactamente con los índices de su archivo, y puede editarlo y volver a correr el script las veces que quiera.
- Al final actualiza las estadísticas (`ANALYZE`) y lista los índices actuales con su tamaño.

| Opción | Por defecto |
| --- | --- |
| `--file` | `indexes.sql` |

## apply_matview.py

Aplica su vista materializada desde `matview.sql`.

- El archivo debe contener **exactamente 1** `CREATE MATERIALIZED VIEW` y, opcionalmente, **1** `CREATE INDEX` sobre esa vista (y `ANALYZE`, si quiere). Nada más.
- Antes de crearla, borra las vistas materializadas que haya creado antes.
- Al final actualiza las estadísticas de la vista y muestra cuántas filas tiene y cuánto espacio ocupa.

| Opción | Por defecto |
| --- | --- |
| `--file` | `matview.sql` |

## check_results.py

Verifica que cada consulta reescrita devuelve **exactamente** el mismo resultado que la original: mismas filas, en el mismo orden.

- Compara los dos archivos etiqueta por etiqueta. Ambos deben tener las mismas 15 etiquetas.
- Solo ejecuta las consultas que cambió. Las demás las cuenta como "sin cambios".
- La base debe tener aplicados sus índices y su vista, porque las reescrituras pueden usarla.
- Para cada consulta reescrita reporta uno de estos resultados:
  - `IGUAL`: devuelve lo mismo.
  - `DISTINTO: mismas filas, pero en otro orden`: revise el `ORDER BY`.
  - `DISTINTO: la original devuelve N filas y la reescrita M`.
  - `DISTINTO desde la fila N`: muestra la primera fila que difiere en ambas versiones.
  - `ERROR`: la consulta falló; se muestra el mensaje de PostgreSQL.
- Termina con código 1 si alguna reescritura da error o no devuelve lo mismo.

Importante: `check_results.py` solo prueba los valores de los parámetros que aparecen en el archivo. Que reporte `IGUAL` no garantiza que su reescritura sirva para cualquier valor; eso debe argumentarlo usted.

| Opción | Por defecto |
| --- | --- |
| `--original` | `workload.sql` |
| `--rewritten` | `workload_after.sql` |

## compare_times.py

Compara los tiempos por consulta de dos o más CSV de `run_workload.py`. El primer archivo es la referencia (normalmente `tiempos_base.csv`).

Para cada consulta y para el total (fila `TOTAL`) muestra:

- **ms:** el tiempo medido.
- **speedup:** cuántas veces más rápido que la referencia. `54.0x` significa 54 veces más rápido.
- **mejora:** lo mismo en porcentaje. `+100%` es el doble de rápido, `+5300%` es 54 veces más rápido, y un valor negativo significa que se puso más lento.

| Opción | Para qué |
| --- | --- |
| `--sort` | Ordena las consultas de la más lenta a la más rápida en la referencia |

## Formato de los archivos de workload

`workload.sql` y `workload_after.sql` tienen una consulta por bloque, cada una precedida por su etiqueta:

```
-- ===== 07 =====
SELECT ...;
```

- No cambie las etiquetas: los scripts comparan las consultas por etiqueta.
- Cada etiqueta debe aparecer una sola vez, y cada bloque debe tener una sola consulta. Si un bloque tiene texto después del `;` o una etiqueta se repite, los scripts se detienen y le indican cuál es.
- Las líneas que empiezan con `--` son comentarios y se ignoran.